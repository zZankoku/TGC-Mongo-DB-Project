<template>
  <div>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <a class="navbar-brand m-2" href="/">GG Esports</a>
      <button
        class="navbar-toggler"
        type="button"
        data-toggle="collapse"
        data-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item">
            <router-link to="/" class="nav-link" tag="a">Home</router-link>
          </li>
          <li class="nav-item">
            <router-link to="/about" class="nav-link" tag="a"
              >About</router-link
            >
          </li>
          <li class="nav-item">
            <router-link to="/games" class="nav-link" tag="a"
              >Games</router-link
            >
          </li>
          <li class="nav-item">
            <router-link to="/signup" class="nav-link" tag="a" v-if="!user"
              >Signup</router-link
            >
          </li>
          <li class="nav-item">
            <router-link to="/login" class="nav-link" tag="a" v-if="!user"
              >Login</router-link
            >
          </li>
          <li class="nav-item" v-if="user">
            <a class="nav-link" @click="logout()">Logout</a>
          </li>
        </ul>
      </div>
    </nav>

    <!-- Home banner section -->
    <div
      class=" header"
      :style="{
        backgroundImage: 'url(' + require('../assets/bg.jpg') + ')',
      }"
    >
      <div class="container text-center header-text">
        <h1>GG E-sports</h1>
        <p>For esports enthusiasts by esports enthusiasts</p>
        <router-link to="/about" class="btn btn-primary" tag="a"
          >More about us</router-link
        >
      </div>
    </div>
    <!-- Home banner section end -->
  </div>
</template>

<script>
export default {
  name: "Home",
  mounted() {
    // Get user data stored in localstorage
    let data = localStorage.getItem("user");
    if (data) {
      this.user = JSON.parse(data);
    }
  },
  methods: {
    logout() {
      // Remove data from localstorage
      localStorage.removeItem("token");
      localStorage.removeItem("user");
      window.location = "/";
    },
  },
  data() {
    return {
      user: this.user,
    };
  },
};
</script>

<style scoped></style>
