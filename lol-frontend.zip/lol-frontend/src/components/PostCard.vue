<template>
  <div class="long-card">
    <div class="long-card-header mb-2">
      <div class="d-flex align-items-center">
        <img src="https://picsum.photos/200/300" alt="" />
        <p>{{ post.postAuthor }}</p>
      </div>
      <p class="text-muted">{{ post.createdDate | timeFilter }}</p>
    </div>
    <h5 class="long-card-title">{{ post.postTitle }}</h5>
    <p class="long-card-desc">{{ post.postContent }}</p>
    <div
      class="d-flex justify-content-between w-100"
      v-if="user && post.postAuthor == user.username"
    >
      <router-link
        class="btn btn-primary"
        :to="'/post/edit/' + post._id"
        tag="button"
        >Edit</router-link
      >
      <button class="btn btn-danger" @click="deletePost(post._id)">
        Delete
      </button>
    </div>
  </div>
</template>

<script>
import moment from "moment";

export default {
  name: "PostCard",
  props: ["post", "user"],
  methods: {
    deletePost(id) {
      // Emit event to parent component
      this.$emit("deletePost", id);
    },
  },
  filters: {
    timeFilter(item) {
      // Parse time to xx time ago format
      return moment(new Date(item)).fromNow();
    },
  },
};
</script>

<style scoped>
.long-card {
  padding: 16px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  border: 1px solid #dbdbdb;
  border-radius: 10px;
  margin-bottom: 1rem;
}
.long-card-title {
  font-weight: bold;
  font-size: 24px;
}
.long-card-desc {
  color: rgb(77, 77, 77);
  font-size: 14px;
}
.long-card-header {
  display: flex;
  width: 100%;
  align-items: center;
  justify-content: space-between;
}
.long-card-header img {
  height: 50px;
  width: 50px;
  border-radius: 50%;
  object-fit: cover;
  margin-right: 1rem;
}
</style>
