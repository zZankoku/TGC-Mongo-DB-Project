<template>
  <div>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <a class="navbar-brand m-2" href="/">GG Esports</a>
      <button
        class="navbar-toggler"
        type="button"
        data-toggle="collapse"
        data-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item">
            <router-link to="/" class="nav-link" tag="a">Home</router-link>
          </li>
          <li class="nav-item">
            <router-link to="/about" class="nav-link" tag="a"
              >About</router-link
            >
          </li>
          <li class="nav-item">
            <router-link to="/games" class="nav-link" tag="a"
              >Games</router-link
            >
          </li>
          <li class="nav-item">
            <router-link to="/signup" class="nav-link" tag="a" v-if="!user"
              >Signup</router-link
            >
          </li>
          <li class="nav-item">
            <router-link to="/login" class="nav-link" tag="a" v-if="!user"
              >Login</router-link
            >
          </li>
          <li class="nav-item" v-if="user">
            <a class="nav-link" @click="logout()">Logout</a>
          </li>
        </ul>
      </div>
    </nav>

    <!-- About section -->
    <div
      class="header"
      :style="{
        backgroundImage: 'url(' + require('../assets/bg-2.png') + ')',
      }"
    >
      <div class="container text-center header-text">
        <h1>About Us</h1>
        <p>
          View all esports games here and contribute to the community in the
          form of posts! Voice out your opinions on games and join others in
          lively discussions!
        </p>
        <br />
        <p>
          For any enquiries or feedback, please reach out to us through any of
          the following channels!
        </p>
        <div class="details">
          <div class="detail">
            <p>Contact: 98268793</p>
            <p>Email: 98268793</p>
          </div>
          <div class="detail">
            <p>Facebook: <a href="#" class="link">@ggesports</a></p>
            <p>Twitter: <a href="#" class="link">@ggesports</a></p>
            <p>Instagram: <a href="#" class="link">@ggesports</a></p>
          </div>
        </div>
      </div>
    </div>
    <!-- About section end -->
  </div>
</template>

<script>
export default {
  name: "About",
  mounted() {
    // Get user data stored in localstorage
    let data = localStorage.getItem("user");
    if (data) {
      this.user = JSON.parse(data);
    }
  },
  methods: {
    logout() {
      // Remove data from localstorage
      localStorage.removeItem("token");
      localStorage.removeItem("user");
      window.location = "/";
    },
  },
  data() {
    return {
      user: this.user,
    };
  },
};
</script>

<style scoped>
.details {
  display: flex;
  justify-content: space-around;
  align-items: flex-start;
}
</style>
