<template>
  <div>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <a class="navbar-brand m-2" href="/">GG Esports</a>
      <button
        class="navbar-toggler"
        type="button"
        data-toggle="collapse"
        data-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item">
            <router-link to="/" class="nav-link" tag="a">Home</router-link>
          </li>
          <li class="nav-item">
            <router-link to="/about" class="nav-link" tag="a"
              >About</router-link
            >
          </li>
          <li class="nav-item">
            <router-link to="/games" class="nav-link" tag="a"
              >Games</router-link
            >
          </li>
          <li class="nav-item">
            <router-link to="/signup" class="nav-link" tag="a" v-if="!user"
              >Signup</router-link
            >
          </li>
          <li class="nav-item">
            <router-link to="/login" class="nav-link" tag="a" v-if="!user"
              >Login</router-link
            >
          </li>
          <li class="nav-item" v-if="user">
            <a class="nav-link" @click="logout()">Logout</a>
          </li>
        </ul>
      </div>
    </nav>

    <div class="container section">
      <div class="mb-5 text-center">
        <h1>Post</h1>
        <p>Write a post and air your opinions!</p>
        <ul>
          <li><p>Post Title: at least 3 characters</p></li>
          <li><p>Post Content: at least 5 characters</p></li>
        </ul>
      </div>

      <form class="default-form" v-if="request">
        <div class="form-group">
          <label for="postTitle">Title</label>
          <input
            required
            v-model="request.postTitle"
            type="text"
            class="form-control"
            id="postTitle"
            placeholder="Enter Title"
          />
        </div>
        <div class="form-group">
          <label for="postContent">Content</label>
          <br />
          <textarea
            id="postContent"
            name="postContent"
            rows="4"
            cols="50"
            v-model="request.postContent"
            class="w-100"
          ></textarea>
        </div>
        <button
          type="submit"
          class="btn btn-primary"
          :disabled="isDisabled"
          @click="handleSubmit()"
        >
          Post
        </button>
        <p
          class="text-center mt-1"
          v-bind:class="{ 'red-text': error, 'green-text': success }"
          v-if="error || success"
        >
          {{ error ? error : success }}
        </p>
      </form>
    </div>
  </div>
</template>

<script>
import axios from "axios";

export default {
  name: "Post",
  mounted() {
    this.edit = this.$route.params.mode == "edit";
    // Get user data stored in localstorage
    let data = localStorage.getItem("user");
    if (data) {
      this.user = JSON.parse(data);
    }
    this.request = {
      postTitle: "",
      postContent: "",
    };
    if (this.edit) {
      // Get post details to edit
      axios
        .get("http://localhost:3000/post/" + this.$route.params.id)
        .then((response) => {
          console.log(response);
          this.request = {
            postTitle: response.data.post.postTitle,
            postContent: response.data.post.postContent,
          };
        })
        .catch((err) => {
          console.log(err);
          this.error = "An error occurred.";
          this.success = null;
        });
    }
  },
  computed: {
    isDisabled: function() {
      return (
        this.request.postTitle.trim().length < 3 ||
        this.request.postContent.trim().length < 5
      );
    },
  },
  methods: {
    logout() {
      // Remove data from localstorage
      localStorage.removeItem("token");
      localStorage.removeItem("user");
      window.location = "/";
    },
    handleSubmit() {
      if (this.edit) {
        // Send post details to backend to update post
        axios
          .put(
            "http://localhost:3000/post/" + this.$route.params.id,
            { ...this.request },
            {
              headers: {
                Authorization: `Bearer ${localStorage.getItem("token")}`,
              },
            }
          )
          .then((response) => {
            console.log(response);
            this.success = "Your post was successfully edited!";
            this.error = null;
          })
          .catch((err) => {
            console.log(err);
            this.error = "An error occurred.";
            this.success = null;
          });
      } else {
        // Send post details to backend to add post
        axios
          .post(
            "http://localhost:3000/post/game/" + this.$route.params.id,
            { ...this.request, postAuthor: this.user.username },
            {
              headers: {
                Authorization: `Bearer ${localStorage.getItem("token")}`,
              },
            }
          )
          .then((response) => {
            console.log(response);
            this.success = "Your post was successfully submitted!";
            this.error = null;
          })
          .catch((err) => {
            console.log(err);
            this.error = "An error occurred.";
            this.success = null;
          });
      }
    },
  },
  data() {
    return {
      user: this.user,
      request: this.request,
      error: this.error,
      success: this.success,
    };
  },
};
</script>

<style scoped></style>
