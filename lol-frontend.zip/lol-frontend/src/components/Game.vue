<template>
  <div>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <a class="navbar-brand m-2" href="/">GG Esports</a>
      <button
        class="navbar-toggler"
        type="button"
        data-toggle="collapse"
        data-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item">
            <router-link to="/" class="nav-link" tag="a">Home</router-link>
          </li>
          <li class="nav-item">
            <router-link to="/about" class="nav-link" tag="a"
              >About</router-link
            >
          </li>
          <li class="nav-item">
            <router-link to="/games" class="nav-link" tag="a"
              >Games</router-link
            >
          </li>
          <li class="nav-item">
            <router-link to="/signup" class="nav-link" tag="a" v-if="!user"
              >Signup</router-link
            >
          </li>
          <li class="nav-item">
            <router-link to="/login" class="nav-link" tag="a" v-if="!user"
              >Login</router-link
            >
          </li>
          <li class="nav-item" v-if="user">
            <a class="nav-link" @click="logout()">Logout</a>
          </li>
        </ul>
      </div>
    </nav>

    <header
      class="small-header"
      :style="{
        backgroundImage: 'url(' + require('../assets/bg-3.jpg') + ')',
      }"
    >
      <div class="container">
        <div class="mb-3 text-center">
          <h1>{{ gameTitle }}</h1>
          <p v-if="game">
            {{ game.startDate | dateFilter }} To {{ game.endDate | dateFilter }}
          </p>
        </div>
      </div>
    </header>

    <!-- Game details section -->
    <section class="grey-bg" v-if="game">
      <div class="container">
        <div class="row">
          <div class="col-lg-6">
            <p class="caption">Description</p>
            <p>{{ game.description }}</p>
            <p class="caption">Sport</p>
            <p>{{ game.sport }}</p>
            <p class="caption">Administrator</p>
            <p>{{ game.administrator }}</p>
          </div>
          <div class="col-lg-6">
            <div class="mb-3">
              <p class="caption">Venue</p>
              <p>{{ game.venue }}</p>
              <p class="caption">Number of Teams</p>
              <p>{{ game.numTeams }}</p>
              <p class="caption">Location</p>
              <p>{{ game.location }}</p>
              <p class="caption">Winners</p>
              <ul>
                <li v-if="game.champion">Champion: {{ game.champion }}</li>
                <li v-if="game.runnerUp">Runner up: {{ game.runnerUp }}</li>
              </ul>
            </div>
          </div>
        </div>
        <div class="row" v-if="user">
          <router-link
            class="btn btn-primary"
            tag="a"
            :to="'/post/game/' + game._id"
            >Post</router-link
          >
        </div>
      </div>
    </section>
    <!-- Game details section end -->

    <!-- Post section -->
    <section class="p-3" v-if="posts && posts.length > 0">
      <div class="container">
        <h2 class="text-center">Posts</h2>
        <div
          class="row d-flex justify-content-center"
          v-for="post in posts"
          :key="post._id"
        >
          <PostCard :post="post" :user="user" @deletePost="deletePost" />
        </div>
      </div>
    </section>
    <!-- Post section end -->
  </div>
</template>

<script>
import axios from "axios";
import moment from "moment";
import PostCard from "./PostCard";

export default {
  name: "Game",
  components: { PostCard },
  computed: {
    gameTitle() {
      return this.game ? this.game.title : "Game";
    },
  },
  mounted() {
    // Get user data stored in localstorage
    let data = localStorage.getItem("user");
    if (data) {
      this.user = JSON.parse(data);
    }
    this.game = null;
    this.posts = [];

    axios
      .get("http://localhost:3000/game/" + this.$route.params.id)
      .then((response) => {
        console.log(response);
        this.game = response.data.game;
        return axios.get(
          "http://localhost:3000/post/game/" + this.$route.params.id
        );
      })
      .then((response) => {
        console.log(response);
        this.posts = response.data.posts;
      })
      .catch((err) => {
        console.log(err);
      });
  },
  filters: {
    dateFilter(item) {
      return item ? moment(new Date(item)).format("YYYY-MM-DD") : "NA";
    },
  },
  methods: {
    logout() {
      // Remove data from localstorage
      localStorage.removeItem("token");
      localStorage.removeItem("user");
      window.location = "/";
    },
    deletePost(id) {
      axios
        .delete("http://localhost:3000/post/" + id, {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        })
        .then((response) => {
          console.log(response);
          window.location.reload();
        })
        .catch((err) => {
          console.log(err);
        });
    },
  },
  data() {
    return {
      user: this.user,
      game: this.game,
      posts: this.posts,
    };
  },
};
</script>

<style scoped>
.caption {
  font-size: 14px;
  font-weight: bold;
  color: rgb(77, 76, 76);
}
</style>
