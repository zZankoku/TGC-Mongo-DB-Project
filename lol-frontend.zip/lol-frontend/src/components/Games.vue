<template>
  <div>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <a class="navbar-brand m-2" href="/">GG Esports</a>
      <button
        class="navbar-toggler"
        type="button"
        data-toggle="collapse"
        data-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item">
            <router-link to="/" class="nav-link" tag="a">Home</router-link>
          </li>
          <li class="nav-item">
            <router-link to="/about" class="nav-link" tag="a"
              >About</router-link
            >
          </li>
          <li class="nav-item">
            <router-link to="/games" class="nav-link" tag="a"
              >Games</router-link
            >
          </li>
          <li class="nav-item">
            <router-link to="/signup" class="nav-link" tag="a" v-if="!user"
              >Signup</router-link
            >
          </li>
          <li class="nav-item">
            <router-link to="/login" class="nav-link" tag="a" v-if="!user"
              >Login</router-link
            >
          </li>
          <li class="nav-item" v-if="user">
            <a class="nav-link" @click="logout()">Logout</a>
          </li>
        </ul>
      </div>
    </nav>

    <header
      class="small-header"
      :style="{
        backgroundImage: 'url(' + require('../assets/bg-3.jpg') + ')',
      }"
    >
      <div class="container">
        <div class="mb-3 text-center">
          <h1>Games</h1>
          <p>View our e-sports games</p>
        </div>
      </div>
    </header>

    <!-- All games section -->
    <div class="container mt-5">
      <div class="row">
        <div
          class="col-lg-6 d-flex justify-content-center"
          v-for="game in games"
          :key="game._id"
        >
          <div class="card m-2">
            <div class="card-body">
              <h5 class="card-title">{{ game.title }}</h5>
              <h6 class="card-subtitle mb-2 text-muted">
                {{ game.startDate | dateFilter }} To
                {{ game.endDate | dateFilter }}
              </h6>
              <p class="card-text">
                {{ game.description }}
              </p>
              <router-link
                :to="{ name: 'Game', params: { id: game._id } }"
                class="btn btn-primary"
                >View More</router-link
              >
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- All games section end -->
  </div>
</template>

<script>
import axios from "axios";
import moment from "moment";

export default {
  name: "Games",
  mounted() {
    // Get user data stored in localstorage
    let data = localStorage.getItem("user");
    if (data) {
      this.user = JSON.parse(data);
    }
    this.games = [];
    axios
      .get("http://localhost:3000/game")
      .then((response) => {
        console.log(response);
        this.games = response.data.games;
      })
      .catch((err) => {
        console.log(err);
      });
  },
  filters: {
    dateFilter(item) {
      // Format date to YYYY-MM-DD format
      return item ? moment(new Date(item)).format("YYYY-MM-DD") : "NA";
    },
  },
  methods: {
    logout() {
      // Remove data from localstorage
      localStorage.removeItem("token");
      localStorage.removeItem("user");
      window.location = "/";
    },
  },
  data() {
    return {
      user: this.user,
      games: this.games,
    };
  },
};
</script>

<style scoped></style>
