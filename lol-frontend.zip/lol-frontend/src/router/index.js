import Home from "../components/Home.vue";
import Signup from "../components/Signup.vue";
import Login from "../components/Login.vue";
import Game from "../components/Game.vue";
import Games from "../components/Games.vue";
import About from "../components/About.vue";
import Post from "../components/Post.vue";

const routes = [
  {
    path: "/",
    name: "Home",
    component: Home,
  },
  {
    path: "/about",
    name: "About",
    component: About,
  },
  {
    path: "/signup",
    name: "Signup",
    component: Signup,
  },
  {
    path: "/login",
    name: "Login",
    component: Login,
  },
  {
    path: "/games",
    name: "Games",
    component: Games,
  },
  {
    path: "/game/:id",
    name: "Game",
    component: Game,
  },
  {
    path: "/post/:mode/:id",
    name: "Post",
    component: Post,
  },
];

export default routes;
